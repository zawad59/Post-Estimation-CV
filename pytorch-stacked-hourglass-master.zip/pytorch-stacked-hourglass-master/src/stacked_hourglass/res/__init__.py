"""Resource files for the stacked_hourglass library.

Data files in this package should be installed alongside the source code, and are read by other
parts of the code using importlib_resources.
"""
